package jp.co.neut.ts.practice.dto.login;

import jp.co.neut.framework.dto.ReturnDto;
import jp.co.neut.ts.practice.entity.MstUser;

public class LoginReturnDto extends ReturnDto {

    public MstUser userInfo;

}