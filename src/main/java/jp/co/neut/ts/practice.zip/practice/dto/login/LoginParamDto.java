package jp.co.neut.ts.practice.dto.login;

import jp.co.neut.framework.dto.ParamDto;

public class LoginParamDto extends ParamDto  {

    public String userId;

    public String pw;
}