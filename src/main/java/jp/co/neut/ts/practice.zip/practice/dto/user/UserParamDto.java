package jp.co.neut.ts.practice.dto.user;

import jp.co.neut.framework.dto.ParamDto;

public class UserParamDto extends ParamDto  {

    public String userId;

    public String userName;

}