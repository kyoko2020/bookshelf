package jp.co.neut.ts.practice.dto.user;

import jp.co.neut.framework.dto.ParamDto;

public class UserEditParamDto extends ParamDto  {

    public String userId;

    public String userName;

    public String pw;

}